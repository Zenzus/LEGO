/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationLayer;


import FunctionLayer.LogicFacade;
import FunctionLayer.LoginSampleException;
import FunctionLayer.User;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jonas
 */
@WebServlet(name = "CustomerServlet", urlPatterns = {"/CustomerServlet"})
public class CustomerServlet extends Command {
    public int[]totaltNeededBricks;
    
    
    User user;
 

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   
    
    @Override
    String execute(HttpServletRequest request, HttpServletResponse response) throws LoginSampleException, ServletException, IOException {
        HttpSession session = request.getSession();

        LogicFacade lCal = new LogicFacade();

        String height = request.getParameter("height");
        String length = request.getParameter("length");
        String width = request.getParameter("width");

        int[] lengthArray = lCal.legoBerigner(Integer.parseInt(length));
        int[] widthArray = lCal.legoBerigner(Integer.parseInt(width) -4);

        totaltNeededBricks = lCal.legoHeight(lengthArray, widthArray, (Integer.parseInt(height)));

        if (Integer.parseInt(length) >= (4) && Integer.parseInt(width) >= 4) {
            
            user = (User) session.getAttribute("user");
            session.setAttribute("totalArray", totaltNeededBricks);
            session.setAttribute("totalNumberBricks", (totaltNeededBricks[0] + totaltNeededBricks[1] + totaltNeededBricks[2]));
            
            lCal.createOrder(user, Integer.parseInt(height),Integer.parseInt(length) ,Integer.parseInt(width));
            
            return "output";
            
           
            
        } else { 
            
            throw new LoginSampleException("You can't build a house like this");
        }

    }
}
   