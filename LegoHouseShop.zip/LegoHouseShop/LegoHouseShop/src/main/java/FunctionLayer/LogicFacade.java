package FunctionLayer;

import DBAccess.UserMapper;
import java.util.ArrayList;

/**
 * The purpose of LogicFacade is to...
 * @author kasper
 */
public class LogicFacade {
    public int[]totaltNeededBricks;

    public static User login( String email, String password ) throws LoginSampleException {
        return UserMapper.login( email, password );
    } 

    public static User createUser( String email, String password ) throws LoginSampleException {
        User user = new User(email, password, "customer", 0);
        UserMapper.createUser( user );
        return user;
    }
    
    public static void createOrder (User user,int height, int length, int width)throws LoginSampleException{ 
        UserMapper.createOrder(user, height, length, width);
        
    }
    
    public int[] legoBerigner(int lenght) {
        
        int[] amount = new int[3];
        
        int brick4 = lenght /4;
        amount[0] = brick4;
        
        int brick2 = (lenght%4)/2;
        amount[1] = brick2;
        
        int brick1 = (lenght%4)/1;
        amount[2] = brick1;
        
        return amount;
    }
    
    public int[] legoHeight(int[] lengthArray,int[]widthArray, int height){
        
        totaltNeededBricks = new int[3];

        totaltNeededBricks[0] = ((lengthArray[0] * 2) + (widthArray[0] * 2)) * height;
        totaltNeededBricks[1] = ((lengthArray[1] * 2) + (widthArray[1] * 2)) * height;
        totaltNeededBricks[2] = ((lengthArray[2] * 2) + (widthArray[2] * 2)) * height;
        return totaltNeededBricks;
    }
    
    public static ArrayList<Orders> getAllOrders(int userID) throws LoginSampleException{
       return UserMapper.getOrder(userID); 
    }
    
    
    
    public static void send(int orderID)throws LoginSampleException{
        UserMapper.markAsSend(orderID);
    }

}
