package FunctionLayer;

/**
 * The purpose of LoginSampleException is to...
 * @author kasper
 */
public class LoginSampleException extends Exception {

    public LoginSampleException(String msg) {
        super(msg);
    }
    

}
