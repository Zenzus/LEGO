/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FunctionLayer;

/**
 *
 * @author jonas
 */
public class Orders {
    
    int userID;
    int orderID;
    int height;
    int length;
    int width;
    int send;

    public Orders(int userID, int orderID, int height, int length, int width, int send) {
        this.userID = userID;
        this.orderID = orderID;
        this.height = height;
        this.length = length;
        this.width = width;
        this.send = send;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getSend() {
        return send;
    }

    public void setSend(int send) {
        this.send = send;
    }

    @Override
    public String toString() {
        return  "<br> The order ID is: " + userID + "<br> The order is:<br> height: " + height + "<br> length: " + length + "<br> width: " + width + "<br> 1 is send 0 is not send "+"<br> SEND status: "+send;
    }
    

    
    
    
}
